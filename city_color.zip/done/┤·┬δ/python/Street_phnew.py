# -*- coding:utf-8 -*-
# _author_: Mr.Wang

import requests
import re
import time
import numpy
import random

# 通过墨卡托坐标构造URl请求获得响应得出id,RoadName
def get_rnamepid(mx,my):
    url = 'https://mapsv0.bdimg.com/?udt=20190717&qt=qsdata&x='+mx+'&y='+my+'&l=12&action=0&mode=day&auth=xQ0yXa4JS%2540a50gY6RO761XIbI1bU50T6uxHLBNHBHzTtxjhNwzWWv1GgvPUDZYOYIZuVt1cv3uVtGccZcuVtPWv3GuxtVwi04960vyACFIMOSU7ulEeLZNz1VD%253DCUbB1A8zv7u%2540ZPuVteuVtegvcguxHLBNHBHzRtlp55C%2540BrZZWuV&t=1563753551123&fn=jsonp83466385'
    headers = {'Referer' : 'https://map.baidu.com/@11583434.64,3560505.83,12z',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36'}
    response = requests.get(url,headers=headers)
    regexerr = '"error":(\d*)'
    patternerr = re.compile(regexerr)
    matcherr = patternerr.findall(response.text)
    errorinfo = int(matcherr[0])
    if errorinfo != 0:
        raise Exception("此点不存在街景图片")


    regex = '"RoadName":"(\w*)"'
    pattern = re.compile(regex)
    match = pattern.findall(response.text)
    if not match[0]:
        match[0]='unknown'

    regex1 = '"id":"(\w*)"'
    pattern1 = re.compile(regex1)
    match1 = pattern1.findall(response.text)

    RoadName = match[0]
    id = match1[0]
    return RoadName,id

# 根据id构造URl请求获得响应得到图片
def get_plist(id):
    a = 1
    b = 0
    p_list = []
    url = 'https://mapsv1.bdimg.com/?qt=pdata&sid='+id+'&pos='+str(a)+'_'+str(b)+'&z=4'
    headers = {'Origin': 'https://map.baidu.com',
            'Referer': 'https://map.baidu.com/@11591170.46,3563621.66,21z,87t,157.76h',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36'}
    response = requests.get(url,headers=headers)
    if response:
        for i in range(4):
            a = 1
            b = i
            url = 'https://mapsv1.bdimg.com/?qt=pdata&sid=' + id + '&pos=' + str(a) + '_' + str(b) + '&z=4'
            response = requests.get(url, headers=headers)
            p_list.append(response.content)

    else:
        for i in range(4, 8):
            a = 1
            b = i
            url = 'https://mapsv1.bdimg.com/?qt=pdata&sid=' + id + '&pos=' + str(a) + '_' + str(b) + '&z=4'
            response = requests.get(url, headers=headers)
            p_list.append(response.content)

    return p_list


# 下载图片
def download_p(p_list,rnam,bd09ll):
    for i in range(4):
        with open("D:\\py\\workpace\\mydata\\"+rnam+'('+str(bd09ll[0])+','+str(bd09ll[1])+')'+str(time.time())+".jpeg","wb") as f:
            f.write(p_list[i])

# 墨卡托坐标转换为百度地图经纬度
def get_bd09ll(mercator):
    ak = 'cBFxHreYUpahyDLuyhyLQRVy5KGDgOGb'
    apiurl = 'http://api.map.baidu.com/geoconv/v1/?coords='+str(mercator[0])+','+str(mercator[1])+'&from=6&to=5&ak='+ak
    response = requests.get(apiurl)

    regexx = '"x":(\d*.\d*)'
    regexy = '"y":(\d*.\d*)'
    patternx = re.compile(regexx)
    patterny = re.compile(regexy)
    matchx = patternx.findall(response.text)
    matchy = patterny.findall(response.text)

    bd09llx = matchx[0]
    bd09lly = matchy[0]
    bd09ll = (float(bd09llx),float(bd09lly))
    return bd09ll



#运行主体（创建一系列随机点坐标加到集合里，并通过点坐标获取该位置街景图片）
# westborder = 119.757527
# eastborder = 120.439377
# northborder = 30.444591
# southborder = 30.069252
mwestborder = 13331491.980134784
meastborder = 13407396.000807742
mnorthborder = 3538977.4865208009
msouthborder = 3490849.509333465
pointset = set()
print('正在创建坐标点集合中，请稍候。。。')
for i in range(500000):
    mx = random.uniform(mwestborder,meastborder)
    my = random.uniform(msouthborder,mnorthborder)
    pointset.add((mx,my))
print('创建完成')
print('开始爬取...')

for i in range(len(pointset)):
    try:
        # mx,my = get_mercator(longitude,latitude)
        mercator = pointset.pop()
        print(i)
        print(str(mercator[0])+'  '+str(mercator[1]))
        rnam,id = get_rnamepid(str(mercator[0]),str(mercator[1]))
        p_list = get_plist(id)
        bd09ll = get_bd09ll(mercator)
        download_p(p_list,rnam,bd09ll)
    except Exception as e:
        print(e)
    time.sleep(0.01)
print('爬取结束！')