import requests
import re
# 墨卡托坐标转换为百度地图经纬度,辅助工具
def get_mercator(bd09ll):
    ak = 'cBFxHreYUpahyDLuyhyLQRVy5KGDgOGb'
    apiurl = 'http://api.map.baidu.com/geoconv/v1/?coords='+str(bd09ll[0])+','+str(bd09ll[1])+'&from=5&to=6&ak='+ak
    response = requests.get(apiurl)

    regexx = '"x":(\d*.\d*)'
    regexy = '"y":(\d*.\d*)'
    patternx = re.compile(regexx)
    patterny = re.compile(regexy)
    matchx = patternx.findall(response.text)
    matchy = patterny.findall(response.text)

    mercatorx = matchx[0]
    mercatory = matchy[0]
    mercator = (float(mercatorx),float(mercatory))
    return mercator
print(get_mercator((119.757527,30.444591)))