# -*- coding:utf-8 -*-
# _author_: Mr.Wang
from haishoku.haishoku import Haishoku
from itertools import chain
import re
import os
import csv

photo_amount = 10143
file_path_list = []
photo_wholecolorinfo = [[0 for i in range(8)] for j in range(photo_amount)]
photo_colorinfo = []


#遍历本地文件夹，获得文件夹里所有图片文件路径
def get_file_path_list():
    global file_path_list
    global photo_amount
    path = 'C:/Users/27539/Desktop/mydata'
    for dirpath, dirnames, filenames in os.walk(path):
        for i in filenames:
            file_path_list.append(path + '/' + i)
    # photo_amount = len(filenames)
    #print(file_path_list)#################################################

#通过haishoku提取图片的主色调，每一张图片可提取8个颜色
def get_photo_wholecolorinfo():
    global photo_wholecolorinfo
    global file_path_list
    global palette
    for i in range(photo_amount):
        get_pdata(file_path_list[i])
        for j in range(8):
            if palette[j]:
                photo_wholecolorinfo[i][j] = palette[j][1]#(hex(palette[0][1][0])[2::]+hex(palette[0][1][1])[2::]+hex(palette[0][1][2])[2::]).upper()
    #print(photo_wholecolorinfo)#####################################

#提取主色调函数
def get_pdata(file_path):#提取主色调
    global palette
    palette = Haishoku.getPalette(file_path)
    #print(palette)

#对得到的最初颜色列表进行遍历删除不符合条件的颜色信息
def get_photo_colorinfo():
    global photo_colorinfo
    #遍历二维数组删除蓝天白云的颜色
    temlist = []
    photo_whcoinlist = list(chain.from_iterable(photo_wholecolorinfo))
    photo_whcoinset = set(photo_whcoinlist)
    for i in photo_whcoinset:
        ctn = photo_whcoinlist.count(i)
        if ctn >= 2:
            temlist.append(i)
    for i in range(len(photo_wholecolorinfo)):
        for j in range(len(photo_wholecolorinfo[i])):
            if photo_wholecolorinfo[i][j] in temlist:
                photo_wholecolorinfo[i][j] = 0

    # for i in range(photo_amount):
    #     for j in range(8):
    #         if photo_wholecolorinfo[i][j] == 'FFFF00':
    #             photo_wholecolorinfo[i][j] = 0欧

    for i in range(photo_amount):
        color = 'N'
        for j in range(8):
            if photo_wholecolorinfo[i][j] != 0:
                color = photo_wholecolorinfo[i][j]
                break
        photo_colorinfo.append((file_path_list[i],color))
    #print(photo_colorinfo)##################################################
    #print(type(photo_colorinfo[0][1]))

#保存颜色信息函数
def save_phcolorinfo():
    id = 1
    #D:/py/workpace/mydata/１号大街(120.33374939535337,30.291286725849943)1563800672.1981633.jpeg
    regex1 = '/(\w*)'
    regex2 = '(\d*.\d*),\d*.\d*'
    regex3 = '\d*.\d*,(\d*.\d*)'
    pattern1 = re.compile(regex1)
    pattern2 = re.compile(regex2)
    pattern3 = re.compile(regex3)


    for i in range(photo_amount):
        match1 = pattern1.findall(photo_colorinfo[i][0])
        match2 = pattern2.findall(photo_colorinfo[i][0])
        match3 = pattern3.findall(photo_colorinfo[i][0])
        name = match1[4]
        longitude = match2[0]
        latitude = match3[0]
        with open('C:\\Users\\27539\\Desktop\\' + 'p_info.csv', 'a', newline='') as f:
            csv_writer = csv.writer(f)
            csv_writer.writerow([id,name,longitude,latitude,photo_colorinfo[i][1]])
        id += 1

#运行主体
get_file_path_list()
print('1')
get_photo_wholecolorinfo()
print('2')

get_photo_colorinfo()
print('3')
save_phcolorinfo()
print('4')