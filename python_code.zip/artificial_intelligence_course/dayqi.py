import requests
import re
import csv
data_list1 = []
data_list2 = []
datelist = ['201102', '201103', '201104', '201105', '201106', '201107', '201108', '201109', '201110', '201111', '201112', '201201', '201202', '201203', '201204', '201205', '201206', '201207', '201208', '201209', '201210', '201211', '201212', '201301', '201302', '201303', '201304', '201305', '201306', '201307', '201308', '201309', '201310', '201311', '201312', '201401', '201402', '201403', '201404', '201405', '201406', '201407', '201408', '201409', '201410', '201411', '201412', '201501', '201502', '201503', '201504', '201505', '201506', '201507', '201508', '201509', '201510', '201511', '201512', '201601', '201602', '201603', '201604', '201605', '201606', '201607', '201608', '201609', '201610', '201611', '201612', '201701', '201702', '201703', '201704', '201705', '201706', '201707', '201708', '201709', '201710', '201711', '201712', '201801', '201802', '201803', '201804', '201805', '201806', '201807', '201808', '201809', '201810', '201811', '201812', '201901', '201902', '201903', '201904', '201905', '201906', '201907', '201908', '201909']
# datelist = ['201910']
# datelist =  ['201102', '201103', '201104']
headers = {
'Host': 'lishi.tianqi.com',
'Referer': 'https://lishi.tianqi.com/hangzhou/index.html',
'Upgrade-Insecure-Requests': '1',
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36'}

for each in datelist:
    response = requests.get('http://lishi.tianqi.com/hangzhou/'+each+'.html',headers=headers)



    regex1 = '<div style="width: 100px">(\-?\d+)</div>'
    regex2 = '<div>(\-?\d+)</div>'
    pattern1 = re.compile(regex1)
    pattern2 = re.compile(regex2)
    match1 = pattern1.findall(response.text)
    match2 = pattern2.findall(response.text)
    # print(len(match1))
    # print(len(match2))

    for i in range(len(match1)):
        data_list1.append(int(match1[i]))
        data_list2.append(int(match2[i]))
        # data_list.append((int(match1[i])+int(match2[i]))//2)
# print(len(data_list))
with open('C:\\Users\\WHR\\Desktop\\dayqih.csv', 'a', newline='') as f:
    csv_writer = csv.writer(f)
    for i in range(len(data_list1)-14):
            csv_writer.writerow([data_list1[i+0],data_list1[i+1],data_list1[i+2],data_list1[i+3],data_list1[i+4],data_list1[i+5],data_list1[i+6],data_list1[i+7],data_list1[i+8],data_list1[i+9],data_list1[i+10],data_list1[i+11],data_list1[i+12],data_list1[i+13],data_list1[i+14],])
with open('C:\\Users\\WHR\\Desktop\\dayqil.csv', 'a', newline='') as f:
    csv_writer = csv.writer(f)
    for i in range(len(data_list2)-14):
            csv_writer.writerow([data_list2[i+0],data_list2[i+1],data_list2[i+2],data_list2[i+3],data_list2[i+4],data_list2[i+5],data_list2[i+6],data_list2[i+7],data_list2[i+8],data_list2[i+9],data_list2[i+10],data_list2[i+11],data_list2[i+12],data_list2[i+13],data_list2[i+14],])

