﻿# -*- coding:utf-8 -*-
# _author_: Mr.Wang

from sklearn.datasets import load_boston
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression, SGDRegressor, Ridge
from sklearn.metrics import mean_squared_error
from sklearn.externals import joblib
import pandas as pd





def linear():
    """
    梯度下降的优化方法对天气进行预测
    :return:
    """
    # 1）获取数据
    data = pd.read_csv("C:\\Users\\WHR\\Desktop\\ml\\dayqih.csv")
    data2 = pd.read_csv("C:\\Users\\WHR\\Desktop\\ml\\dayqil.csv")
    #x可以是pandas的DataFrame，y可以是pandas的Series，scikit-learn可以理解这种结构
    x = data[['day1','day2','day3','day4','day5','day6','day7','day8','day9','day10','day11','day12','day13','day14']]
    # print(x.head())
    y = data['day15']
    # print(y.head())

    x2 = data2[['day1','day2','day3','day4','day5','day6','day7','day8','day9','day10','day11','day12','day13','day14']]
    # print(x.head())
    y2 = data2['day15']
    # print(y.head())

    # 2）划分数据集
    x_train, x_test, y_train, y_test = train_test_split(x, y, random_state=22)
    x_train2, x_test2, y_train2, y_test2 = train_test_split(x2, y2, random_state=22)
    # 3）标准化
    transfer = StandardScaler()
    x_train = transfer.fit_transform(x_train)
    x_test = transfer.transform(x_test)


    transfer2 = StandardScaler()
    x_train2 = transfer2.fit_transform(x_train2)
    x_test2 = transfer2.transform(x_test2)

    # 4）预估器
    estimator = SGDRegressor(learning_rate="constant", eta0=0.001, max_iter=100000, penalty="l1")
    estimator.fit(x_train, y_train)

    estimator2 = SGDRegressor(learning_rate="constant", eta0=0.001, max_iter=100000, penalty="l1")
    estimator2.fit(x_train2, y_train2)

    # 5）得出模型
    print("梯度下降-权重系数为：\n", estimator.coef_)
    print("梯度下降-偏置为：\n", estimator.intercept_)

    print("梯度下降-权重系数为：\n", estimator2.coef_)
    print("梯度下降-偏置为：\n", estimator2.intercept_)

    # 6）模型评估
    y_predict = estimator.predict(x_test)
    print("预测最高气温：\n", y_predict)
    error = mean_squared_error(y_test, y_predict)
    print("梯度下降-均方误差为：\n", error)

    y_predict2 = estimator2.predict(x_test2)
    print("预测最低气温：\n", y_predict2)
    error2 = mean_squared_error(y_test2, y_predict2)
    print("梯度下降-均方误差为：\n", error2)


    data_test = pd.read_csv("C:\\Users\\WHR\\Desktop\\ml\\dayqith.csv")
    # X = data_test.drop(['day15'],axis=1)
    X = data_test[['day1','day2','day3','day4','day5','day6','day7','day8','day9','day10','day11','day12','day13','day14']]
    Y = data_test['day15']
    X = transfer.transform(X)
    p_list = estimator.predict(X)
    print("最高气温：")
    for each in p_list:
        print(each)
    error3 = mean_squared_error(Y, p_list)
    print("梯度下降-均方误差为：\n", error3)



    data_test2 = pd.read_csv("C:\\Users\\WHR\\Desktop\\ml\\dayqitl.csv")
    # X = data_test.drop(['day15'],axis=1)
    X2 = data_test2[['day1','day2','day3','day4','day5','day6','day7','day8','day9','day10','day11','day12','day13','day14']]
    Y2 = data_test2['day15']
    X2 = transfer2.transform(X2)
    p_list2 = estimator2.predict(X2)
    print("最低气温：")
    for each in p_list2:
        print(each)
    error4 = mean_squared_error(Y2, p_list2)
    print("梯度下降-均方误差为：\n", error4)
    return None




if __name__ == "__main__":
    linear()