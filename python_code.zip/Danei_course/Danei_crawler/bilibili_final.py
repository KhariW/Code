# -*- coding:utf-8 -*-
# _author_: Mr.Wang
import csv
import time
from functools import wraps

from lxml import etree
from selenium import webdriver

# 链接数据库
from redis import Redis
host = "192.168.43.132"
key = "bilibiliUrl"
r = Redis(host=host, port=6379, password="kainredis")
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
#

def getUrl():
    url = r.spop(key)
    if url:
        url = url.decode("utf-8")
    return url


def putUrl(url, key):
    '''
    将URL存入数据库
    成功返回True
    否则返回None
    '''
    try:
        r.sadd(key, url)
        return True
    except:
        return None


# 异常捕获装饰器
def noError(func):
    @wraps(func)
    def inner(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            print("Error: %r" % e)

    return inner


@noError
def get_video_info(url):
    # 参数：url
    # 返回：final_list(#所有信息),titlelist(#视频标题),urllist(#视频url),playlist(#播放量),danmulist(#弹幕量)，typelist(#视频类别)
    # 写入："D:\\py\\workpace\\mydata\\"+str(time.time())+".txt"
    driver = webdriver.Chrome()
    driver.get(url)
    driver.implicitly_wait(5)
    for y in range(75):
        js = "window.scrollBy(0,100)"
        driver.execute_script(js)
        time.sleep(0.2)
    res = driver.page_source
    driver.close()

    bilibili = etree.HTML(res)
    titlelist = bilibili.xpath('//div[@class="spread-module"]/a[@target="_blank"]/p[@class="t"]/@title')
    urllis = bilibili.xpath('//div[@class="spread-module"]/a[@target="_blank"]/@href')
    playlist = bilibili.xpath(
        '//div[@class="spread-module"]/a[@target="_blank"]/p[@class="num"]/span[@class="play"]/text()')
    danmulist = bilibili.xpath(
        '//div[@class="spread-module"]/a[@target="_blank"]/p[@class="num"]/span[@class="danmu"]/text()')

    # for i in urllis:
    #     print(i)
    # print(len(urllis))
    urllist = []
    for url in urllis:
        if 'www.bilibili.com' in url:
            urllist.append("https:" + url)
            playlist.insert(0, '-1')
            danmulist.insert(0, '-1')
        else:
            urllist.append("https://www.bilibili.com" + url)

    typelist = []
    for i in range(len(titlelist)):
        driver2 = webdriver.Chrome()
        driver2.get(urllist[i])
        driver2.implicitly_wait(5)
        # for y in range(100):
        #     js = "window.scrollBy(0,100)"
        #     driver.execute_script(js)
        #     time.sleep(0.2)
        res2 = driver2.page_source
        driver2.close()
        type_ = etree.HTML(res2)
        typelis = type_.xpath('//div[@id="app"]//div[@class="video-data"]//a[@target="_blank"]/text()')
        typelist.append(typelis[0] + ">" + typelis[1])

    final_list = []
    for i in range(len(titlelist)):
        final_list.append(
            titlelist[i] + " " + urllist[i] + " " + "播放量：" + playlist[i] + " " + "弹幕量：" + danmulist[i] + " " + "视频类别：" +
            typelist[i] + "\n")

    return titlelist, urllist, playlist, danmulist, typelist


def run():
    while 1:
        try:
            url = getUrl()
            if 'www.bilibili.com/v/' not in url:
                putUrl(url, "bilibiliUrl")
            else:
                titlelist, urllist, playlist, danmulist, typelist = get_video_info(url)
                print("爬取成功 -> {}".format(url))
                with open('D:\\py\\workpace\\mydata'+'csv_test2.csv', 'a', newline='') as f:
                    csv_writer = csv.writer(f)
                    for i in range(len(titlelist)):
                        flag = putUrl(url, 'bilibiliUrlBack')
                        if flag:
                            putUrl(url, 'bilibiliUrl')
                        csv_writer.writerow([titlelist[i], playlist[i], danmulist[i], typelist[i]])

        except:
            break


if __name__ == '__main__':
    from threading import Thread

    threadList = []

    for i in range(5):
        t = Thread(target=run, args=())
        t.start()
        threadList.append(t)

    for t in threadList:
        t.join()

