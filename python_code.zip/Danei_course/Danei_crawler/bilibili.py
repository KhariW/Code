# -*- coding:utf-8 -*-
# _author_: Mr.Wang
import random
import time
from lxml import etree
from selenium import webdriver

def get_video_info(url):
    #参数：url
    #返回：final_list(#所有信息),titlelist(#视频标题),urllist(#视频url),playlist(#播放量),danmulist(#弹幕量)，typelist(#视频类别)
    #写入："D:\\py\\workpace\\mydata\\"+str(time.time())+".txt"
    driver = webdriver.Chrome()
    driver.get(url)
    driver.implicitly_wait(5)
    for y in range(75):
        js = "window.scrollBy(0,100)"
        driver.execute_script(js)
        time.sleep(0.2)
    res = driver.page_source
    driver.close()

    bilibili = etree.HTML(res)
    titlelist = bilibili.xpath('//div[@class="spread-module"]/a[@target="_blank"]/p[@class="t"]/@title')
    urllis = bilibili.xpath('//div[@class="spread-module"]/a[@target="_blank"]/@href')
    playlist = bilibili.xpath('//div[@class="spread-module"]/a[@target="_blank"]/p[@class="num"]/span[@class="play"]/text()')
    danmulist = bilibili.xpath('//div[@class="spread-module"]/a[@target="_blank"]/p[@class="num"]/span[@class="danmu"]/text()')


    # for i in urllis:
    #     print(i)
    # print(len(urllis))
    urllist = []
    for url in urllis:
        if 'www.bilibili.com' in url:
            urllist.append("https:"+url)
            playlist.insert(0,'-1')
            danmulist.insert(0,'-1')
        else:
            urllist.append("https://www.bilibili.com"+url)

    typelist = []
    for i in range(len(titlelist)):
        driver2 = webdriver.Chrome()
        driver2.get(urllist[i])
        driver2.implicitly_wait(5)
        # for y in range(100):
        #     js = "window.scrollBy(0,100)"
        #     driver.execute_script(js)
        #     time.sleep(0.2)
        res2 = driver2.page_source
        driver2.close()
        type_ = etree.HTML(res2)
        typelis = type_.xpath('//div[@id="app"]//div[@class="video-data"]//a[@target="_blank"]/text()')
        typelist.append(typelis[0]+">"+typelis[1])

    final_list = []
    for i in range(len(titlelist)):
        final_list.append(titlelist[i]+" "+urllist[i]+" "+"播放量："+playlist[i]+" "+"弹幕量："+danmulist[i]+" "+"视频类别："+typelist[i]+"\n")

    f = open("D:\\py\\workpace\\mydata\\"+str(time.time())+".txt","w")
    for i in range(len(final_list)):
        f.write(final_list[i])
        print(final_list[i])
    f.close()
    return final_list,titlelist,urllist,playlist,danmulist,typelist


url_list = [
'https://www.bilibili.com/v/douga/voice/#/1150302#/8623556',
'https://www.bilibili.com/v/ent/star/#/5822794',
'https://www.bilibili.com/v/anime/information/#/1732#/8881#/all',
'https://www.bilibili.com/v/game/music/#/36877#/11298',
'https://www.bilibili.com/v/digital/pc/#/35654#/21216#/1338',
'https://www.bilibili.com/v/dance/three_d/#/8562#/57156#/57156',
'https://www.bilibili.com/v/life/sports/#/236568#/53206#/2687',
'https://www.bilibili.com/v/technology/mechanical/#/49979#/60624',
'https://www.bilibili.com/v/life/sports/#/60781#/16249',
'https://www.bilibili.com/v/game/music/#/280531#/all/default/0',
'https://www.bilibili.com/v/digital/photography/#/681492#/3156#/all/default',
'https://www.bilibili.com/v/technology/military/#/3566299#/116480#/3079',
'https://www.bilibili.com/v/technology/wild/#/37699#/6149#/3620',
'https://www.bilibili.com/v/anime/information/#/6126#/13748',
'https://www.bilibili.com/v/technology/mechanical/#/34321#/194803#/5794',
'https://www.bilibili.com/v/digital/intelligence_av/#/353057#/1585617',
'https://www.bilibili.com/v/digital/pc/#/299685#/169574#/252274',
'https://www.bilibili.com/v/life/daily/#/all/default/0#/all/click/0/1/2019-06-30,2019-07-07#/all/click/0/1/2019-06-30,2019-07-07',
'https://www.bilibili.com/v/guochuang/puppetry/#/3064493#/all/default#/669892',
'https://www.bilibili.com/v/game/online/#/607412#/394538',
'https://www.bilibili.com/v/technology/mechanical/#/9722#/1652#/536'
]
url_ = random.choice(url_list)

if 'www.bilibili.com/v/' in url_:
    get_video_info(url_)


