# -*- coding:utf-8 -*-
# _author_: Mr.Wang
from bs4 import BeautifulSoup
from lxml import etree
import requests

url = 'https://so.gushiwen.org/shiwenv_36f7fe5bb93b.aspx'
response = requests.get(url)
soup = BeautifulSoup(response.text,'lxml')
print(soup.select('div[class="cont"]>h1')[0].get_text())

print(soup.select('div[class="cont"]>p[class="source"]>a')[0].get_text())

print(soup.select('div[class="cont"]>p[class="source"]>a')[1].get_text())

print(soup.select('div[class="cont"]>div[class="contson"]')[0].get_text())

print(soup.select('div[class="contyishang"]>p')[0].get_text())
print(soup.select('div[class="contyishang"]>p')[1].get_text())
