# -*- coding:utf-8 -*-
# _author_: Mr.Wang

import requests
from lxml import etree
import re

# headers = {'Referer': 'https://www.bilibili.com/v/technology/?spm_id_from=333.334.b_7072696d6172795f6d656e75.47',
# 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36'
# }
# response = requests.get("https://api.bilibili.com/x/web-interface/dynamic/region?callback=jqueryCallback_bili_47137630532415864&jsonp=jsonp&ps=15&rid=122&_=1562727150716",headers=headers)
# regex = '"aid":(\d*)'
# pattern = re.compile(regex)
# match = pattern.findall(response.text)
# print(len(match))
# for i in range(len(match)):
#     print('https://www.bilibili.com/video/av'+match[i])

url = 'https://space.bilibili.com/139525612/'
regex_ = '\d+'
pattern = re.compile(regex_)
match = pattern.findall(url)


headers = {'Referer': 'https://space.bilibili.com/'+match[0]+'/',
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36'}
view_response = requests.get('https://api.bilibili.com/x/space/upstat?mid='+match[0]+'&jsonp=jsonp&callback=__jp4',headers=headers)
fans_response = requests.get('https://api.bilibili.com/x/relation/stat?vmid='+match[0]+'&jsonp=jsonp&callback=__jp3',headers=headers)


regex_2 = '"archive":{"view":(\d*)}'
pattern2 = re.compile(regex_2)
match2 = pattern2.findall(view_response.text)

regex_3 = '"follower":(\d*)'
pattern3 = re.compile(regex_3)
match3 = pattern3.findall(fans_response.text)
print("播放量："+match2[0])
print("粉丝数："+match3[0])

