# -*- coding:utf-8 -*-
# _author_: Mr.Wang
import requests
import re

url = 'http://www.shicimingju.com/book/'
response = requests.get(url)
######爬取书籍名称
bookname = '"/book/[a-zA-Z]*\.html">\w*'
pattern = re.compile(bookname)
match = pattern.findall(response.text)
booknamelist = []
chapterurlist = []
for each in match:
    eachlist = each.split('>')
    booknamelist.append(eachlist[1])
    chapterurlist.append(eachlist[0])
booknamelist.remove("史书典籍")
chapterurlist.remove(chapterurlist[0])
# print(booknamelist)
# print(chapterurlist)


chapterurl = 'http://www.shicimingju.com'
booknamei = input('请输入书籍名称：')
bo = 1
try:
    for each in booknamelist:
        if booknamei == each:
            chapterurl = chapterurl + chapterurlist[booknamelist.index(each)][1:-1:]
            bo = 0
    if bo==1:
        raise Exception("sb")
except Exception as e:
    print("书籍不存在", e)
# print(chapterurl)


f = open(booknamei, 'w', encoding='utf-8')
response2 = requests.get(chapterurl)
# print(response2.text)
chaptername = '<li>\s*<a href="/book/.+?\.html">(.+?)</a>'
chapterlink = '<li>\s*<a href="(/book/.+?\.html)">.+?</a>'
pattern2 = re.compile(chaptername)
pattern22 = re.compile(chapterlink)
match1 = pattern2.findall(response2.text)
match2 = pattern22.findall(response2.text)
# print(match1)
# print(match2)
chapternamelist = match1
chaptertext = match2

chaptertextcon = '<p>(.*)</p>'
pattern3 = re.compile(chaptertextcon)

chaptertextcon2 = '<div class="chapter_content">\s*(.*?)\s*</div>'
pattern32 = re.compile(chaptertextcon2)
for each in range(len(chapternamelist)):
    print(chapternamelist[each] + '正在爬取中')
    chaptertexturl = 'http://www.shicimingju.com'
    chaptertexturl = chaptertexturl + chaptertext[each]
    response3 = requests.get(chaptertexturl)

    match = pattern3.findall(response3.text)
    if len(match):
        match = [each.replace("\xa0", "") for each in match]
        match = [each.replace("&nbsp", "") for each in match]
        match = [each.replace(";", "") for each in match]
        f.write(chapternamelist[each])
        f.write('\n')
        for each2 in match:
            f.write(each2)
        f.write('\n')
    if not len(match):
        match = pattern32.findall(response3.text)
        match = [each.replace("\u3000", "") for each in match]
        match = [each.replace("</h3>", "") for each in match]
        match = [each.replace("<h3>", "") for each in match]
        match = [each.replace("<br>", "") for each in match]
        match = [each.replace("<p>", "") for each in match]
        match = [each.replace("&nbsp", "") for each in match]
        match = [each.replace(";", "") for each in match]
        f.write(chapternamelist[each])
        f.write('\n')
        for each2 in match:
            f.write(each2)
        f.write('\n')
f.close()
