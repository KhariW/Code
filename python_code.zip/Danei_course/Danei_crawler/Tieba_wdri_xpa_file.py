# -*- coding:utf-8 -*-
# _author_: Mr.Wang
import time
import requests
import random
from lxml import etree
from selenium import webdriver

kw = input('请输入吧名：')
list1 = []
for k in range(1500):
    list1.append(k)
for i in range(10):
    driver = webdriver.Chrome()
    url = 'http://tieba.baidu.com/f?ie=utf-8&kw=' + kw + '&fr=search&red_tag=h0821967003'
    pn = i*50
    url = url + '&pn=%d'%pn

    driver.get(url)
    driver.implicitly_wait(5)
    for y in range(100):
        js = "window.scrollBy(0,100)"
        driver.execute_script(js)
        time.sleep(0.2)
    text = driver.page_source
    driver.close()

    htm = etree.HTML(text)
    imagelist = htm.xpath('//div/ul/li/a/img/@bpic')
    #for image1 in imagelist:
        #print(image1)
    for imag in imagelist:
        print(imag)
    print(len(imagelist))
    for j in range(len(imagelist)):
        nam = random.choice(list1)
        list1.remove(nam)
        response = requests.get(imagelist[j])
        with open("D:\\py\\workpace\\mydata\\"+str(nam)+".jpg", "wb") as f:
            f.write(response.content)

driver.close()
