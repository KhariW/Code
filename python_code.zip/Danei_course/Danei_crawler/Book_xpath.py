# -*- coding:utf-8 -*-
# _author_: Mr.Wang
import requests
from lxml import etree
url = 'http://www.shicimingju.com/book/'


def get_book(url2):
    response = requests.get(url2)
    res = etree.HTML(response.text)
    bookname = res.xpath('//div[@class="bookmark-list"]//li/h2/a/text()')
    booklink = res.xpath('//div[@class="bookmark-list"]//li/h2/a/@href')
    for i in range(len(booklink)):
        booklink[i] = 'http://www.shicimingju.com' + booklink[i]
    return bookname,booklink
def get_chapter(url3):
    response = requests.get(url3)
    res = etree.HTML(response.text)
    chaptername = res.xpath('//div[@class="book-mulu"]//li/a/text()')
    chapterlink = res.xpath('//div[@class="book-mulu"]//li/a/@href')

    for i in range(len(chapterlink)):
        chapterlink[i] = 'http://www.shicimingju.com' + chapterlink[i]
    return chaptername,chapterlink
def get_chaptertext(url4):
    response = requests.get(url4)
    res = etree.HTML(response.text)
    chaptertext = res.xpath('//div[@class="chapter_content"]/p/text()')
    if chaptertext:
        return chaptertext
    else:
        chaptertext = res.xpath('//div[@class="chapter_content"]/text()')
        return chaptertext

bookn,bookl = get_book(url)

# for each in bookn:
#      print(each)
bookname = input('请输入你想看的书：')
b1 = 0
c1 = 0
for index, each in enumerate(bookn):
    if each == bookname:
        b1 = index
chaptern,chapterl = get_chapter(bookl[b1])
# print(chaptern)
# print(chapterl)
chaptername = int(input('请输入你想看第几章：'))
text1 = get_chaptertext(chapterl[chaptername])
for tex in text1:
    print(tex)


















