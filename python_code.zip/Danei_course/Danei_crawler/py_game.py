                                                                                    # # -*- coding:utf-8 -*-
# # _author_: Mr.Wang
import pygame
import sys
import random
import time
screen = pygame.display.set_mode((700,500))
sImage = 'C:/Users/27539/Desktop/star.PNG'
star = pygame.image.load(sImage)
list = [[],[]]
c = 1
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()
    while c == 1:
        for i in range(100):
            x = random.randint(0, 700)
            y = random.randint(0, 500)
            list[0].append(x)
            list[1].append(y)
            pygame.draw.rect(screen, (255, 255, 255), (0, 0, 700, 500))
            screen.blit(star, (x, y))
            pygame.display.update()
        c = 0
    pygame.draw.rect(screen,(255,255,255),(0,0,700,500))
    for j in range(100):
        list[1][j]+=1
        if list[1][j]>=500:
            list[1][j] = 0
            list[0][j] = random.randint(0,700)
    for k in range(100):
        screen.blit(star, (list[0][k], list[1][k]))
    pygame.display.update()
    time.sleep(0.1)
