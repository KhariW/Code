# -*- coding:utf-8 -*-
# _author_: Mr.Wang
# 元组不可变，字典和集合不可迭代
import pygame
import sys
import random
import time
alist = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
alist2 =[]#[[a,400,0],[b,300,0]]
x = random.randint(0,700)
y = random.randint(0,300)
a = random.randint(0,25)
alist2.append([alist[a], x, y])
for i in range(20):
    x = random.randint(0,700)
    y = random.randint(0,300)
    a = random.randint(0,25)
    alist2.append([alist[a],x,y])
pygame.init()
screen = pygame.display.set_mode((700,500))
my_font = pygame.font.Font(None,20)
ac = 100
rinum = 0
wrnum = 0
max = 0
f = open('test.txt','r+')
max1 = f.read()
if max1:
    max = int(max1)
while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                if ac>max:
                    max = ac
                    f = open('test.txt', 'w+')
                    f.write(str(ac))
                    f.close()
                f.close()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                sym = 0
                for each in alist2:
                    if each[0] == chr(event.key):
                        alist2.remove(each)
                        x = random.randint(0, 700)
                        y = 0
                        a = random.randint(0, 25)
                        alist2.append([alist[a], x, y])
                        if rinum%15==0 and rinum!=0:
                            ac+=20
                        else:
                            ac+=10
                        rinum+=1
                        wrnum = 0
                        sym = 1
                        break
                if sym == 0:
                    wrnum+=1
                    rinum = 0
                    if wrnum%3==0 and wrnum!=0:
                        ac-=20
                    else:
                        ac-=10
        pygame.draw.rect(screen, (255, 255, 255), (0, 0, 700, 500))
        for i in range(len(alist2)):
            font_image = my_font.render('%s'%alist2[i][0], True,(0,0,0))
            screen.blit(font_image, (alist2[i][1], alist2[i][2]))
            alist2[i][2]+=1
        font_image2 = my_font.render('%d'%ac,True,(0,0,0))
        screen.blit(font_image2,(0,0))

        font_image3 = my_font.render('%s' %max, True, (0, 0, 0))
        screen.blit(font_image3, (0, 480))
        pygame.display.update()
        if ac<=0:
            exit(0)
        time.sleep(0.1)



