#             number                       identifier                      (                              )                   $
# lexp        lexp->atom                   lexp->atom                      lexp->list
# atom        atom->number                 atom->identifier
# list                                                                     list->(lexp-seq)
# lexp-seq    lexp-seq->lexp lexp-seq'     lexp-seq->lexp lexp-seq'        lexp-seq->lexp lexp-seq'
# lexp-seq'   lexp-seq'->lexp lexp-seq'    lexp-seq'->lexp lexp-seq'       lexp-seq'->lexp lexp-seq'      lexp-seq'->ε

# 输入：(identifier(identifier(number))(identifier))
# 输出：yes

# (!identifier!(!identifier!(!number!)!)!(!identifier!)!)!#      完全正确：例题输入
# (!identifier!)!#                      正确
# (!number!)!)!(!identifier!)!)!#       错误：缺少前括号
# (!identifier!(!identifier!(!number!)# 错误：缺少后括号
# (!identifier!)!(!number!)!#           错误：此句子不是该句型
# (!identifier!number!)!#               正确：此句子应是该句型
flag = True
token_list = []

def lexp_():
    global token_list
    global  flag
    if  flag == False:
        return
    if token_list[0] == 'number':
        atom_()
        return
    elif token_list[0] == 'identifier':
        atom_()
        return
    elif token_list[0] == '(':
        list_()
        return
    else:
        flag = False
        return
def atom_():
    global token_list
    global flag
    if flag == False:
        return
    if token_list[0] == 'number':
        token_list.remove(token_list[0])
        return
    elif token_list[0] == 'identifier':
        token_list.remove(token_list[0])
        return
    else:
        flag = False
        return
def list_():
    global token_list
    global flag
    if flag == False:
        return
    if token_list[0] == '(':
        token_list.remove(token_list[0])
        lexp_seq()
        if token_list[0] == ')':
            token_list.remove(token_list[0])
            return
        else:
            flag = False
            return
    else:
        flag = False
        return
def lexp_seq():
    global token_list
    global flag
    if flag == False:
        return
    if token_list[0] == 'number' or token_list[0] == 'identifier'or token_list[0] == '(':
        lexp_()
        lexp_seqp()
        return
    else:
        flag = False
        return
def lexp_seqp():
    global token_list
    global flag
    if flag == False:
        return
    if token_list[0] == 'number' or token_list[0] == 'identifier' or token_list[0] == '(':
        lexp_()
        lexp_seqp()
        return
    elif token_list[0] == ')':
        return
    else:
        flag = False
        return

if __name__ == '__main__':
    str = input("请输入字符串(token与token之间以!为分割，字符串以#结束)：")
    token_list = str.split('!')
    token_list.remove(token_list[-1])
    print(token_list)
    try:
        lexp_()
    except Exception:
        flag = False
    if flag == True and token_list == []:
        print('yes!')
    else:
        print('no!')
