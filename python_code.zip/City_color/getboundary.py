import matplotlib.pyplot as plt
import numpy as np
import re

# 传入顶点的x坐标，y坐标，生成的点个数num
def pltShow(xx, yy, num):
    z = np.random.random(size=[xx.size, num])

    x = (z / sum(z)).T.dot(xx)
    y = (z / sum(z)).T.dot(yy)

    # 绘制点：黄色
    plt.plot(x, y, 'yo')
    plt.grid(True)

    # 绘制顶点：绿色
    for i in range(xx.size):
        plt.plot(xx[i], yy[i], 'go')

    plt.show()





if __name__ == '__main__':


    with open("C:\\Users\\27539\\Desktop\\download.csv" , "rb") as f:
        a = f.read()
    b = a.decode('utf-8')
    regex = "\d+.\d+"
    pattern = re.compile(regex)
    match = pattern.findall(b)
    match2 = []
    match3 = []
    for i in range(len(match)):
        if i%2 == 0:
            match2.append(match[i])
        else:
            match3.append(match[i])
    for i in range(len(match2)):
        match2[i] = float(match2[i])
        match3[i] = float(match3[i])
    match2 = np.array(match2)
    match3 = np.array(match3)
    print(match2)
    print(match3)

    pltShow(match2,match3, 100000)

