import requests
import re
# 墨卡托坐标转换为百度地图经纬度,辅助工具
def get_mercator(bd09ll):
    ak = 'cBFxHreYUpahyDLuyhyLQRVy5KGDgOGb'
    apiurl = 'http://api.map.baidu.com/geoconv/v1/?coords='+str(bd09ll[0])+','+str(bd09ll[1])+'&from=5&to=6&ak='+ak
    response = requests.get(apiurl)

    regexx = '"x":(\d*.\d*)'
    regexy = '"y":(\d*.\d*)'
    patternx = re.compile(regexx)
    patterny = re.compile(regexy)
    matchx = patternx.findall(response.text)
    matchy = patterny.findall(response.text)

    mercatorx = matchx[0]
    mercatory = matchy[0]
    mercator = (float(mercatorx),float(mercatory))
    return mercator
def get_bd09ll(mercator):
    ak = 'cBFxHreYUpahyDLuyhyLQRVy5KGDgOGb'
    apiurl = 'http://api.map.baidu.com/geoconv/v1/?coords='+str(mercator[0])+','+str(mercator[1])+'&from=6&to=5&ak='+ak
    response = requests.get(apiurl)

    regexx = '"x":(\d*.\d*)'
    regexy = '"y":(\d*.\d*)'
    patternx = re.compile(regexx)
    patterny = re.compile(regexy)
    matchx = patternx.findall(response.text)
    matchy = patterny.findall(response.text)

    bd09llx = matchx[0]
    bd09lly = matchy[0]
    bd09ll = (float(bd09llx),float(bd09lly))
    return bd09ll
# print(get_mercator((119.757527,30.444591)))
print(get_bd09ll((11094682.924996886,3821030.2797620073)))
