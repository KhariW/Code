# -*- coding:utf-8 -*-
# _author_: Mr.Wang
from PIL import Image as PImage, ImageTk
from tkinter import *
from tkinter import filedialog
from tkinter import font as tkFont
from haishoku.haishoku import Haishoku
import re
import os
import csv

window = Tk()
window.title('色彩主色调提取系统')
window.geometry('1020x560')


def Upload_Img(btn2,btn3):
    global Img
    global img_jpeg
    global file_path
    global palette
    btn2.config(state=NORMAL)
    btn3.config(state=NORMAL)
    file_path = filedialog.askopenfilename()
    Img = PImage.open(file_path)
    print(file_path)
    img_jpeg = ImageTk.PhotoImage(Img)
    label_image = Label(image=img_jpeg)
    label_image.place(x=240,y=20,height=512,width=512)


    ft = tkFont.Font(size=15, weight=tkFont.BOLD)
    Label(text='主色调：', foreground="red", font=ft).place(x=790, y=40, height=75, width=100)
    get_pdata()
    if palette[0]:
        str1 = (hex(palette[0][1][0])[2::]+hex(palette[0][1][1])[2::]+hex(palette[0][1][2])[2::]).upper()
    else:
        str1 = 'FFFF00'
    col_button1 = Button(bg='#'+str1, command=lambda : delete_col(col_button1,0))
    col_button1.place(x=800, y=120, height=30, width=75)

    if palette[1]:
        str2 = (hex(palette[1][1][0])[2::] + hex(palette[1][1][1])[2::] + hex(palette[1][1][2])[2::]).upper()
    else:
        str2 = 'FFFF00'
    col_button2 = Button(bg='#'+str2, command=lambda : delete_col(col_button2,1))
    col_button2.place(x=800, y=170, height=30, width=75)

    if palette[2]:
        str3 = (hex(palette[2][1][0])[2::] + hex(palette[2][1][1])[2::] + hex(palette[2][1][2])[2::]).upper()
    else:
        str3 = 'FFFF00'
    col_button3 = Button(bg='#'+str3, command=lambda : delete_col(col_button3,2))
    col_button3.place(x=800, y=220, height=30, width=75)

    if palette[3]:
        str4 = (hex(palette[3][1][0])[2::] + hex(palette[3][1][1])[2::] + hex(palette[3][1][2])[2::]).upper()
    else:
        str4 = 'FFFF00'
    col_button4 = Button(bg='#'+str4, command=lambda : delete_col(col_button4,3))
    col_button4.place(x=800, y=270, height=30, width=75)

    if palette[4]:
        str5 = (hex(palette[4][1][0])[2::] + hex(palette[4][1][1])[2::] + hex(palette[4][1][2])[2::]).upper()
    else:
        str5 = 'FFFF00'
    col_button5 = Button(bg='#'+str5, command=lambda : delete_col(col_button5,4))
    col_button5.place(x=800, y=320, height=30, width=75)

    if palette[5]:
        str6 = (hex(palette[5][1][0])[2::] + hex(palette[5][1][1])[2::] + hex(palette[5][1][2])[2::]).upper()
    else:
        str6 = 'FFFF00'
    col_button6 = Button(bg='#'+str6, command=lambda : delete_col(col_button6,5))
    col_button6.place(x=800, y=370, height=30, width=75)

    if palette[6]:
        str7 = (hex(palette[6][1][0])[2::] + hex(palette[6][1][1])[2::] + hex(palette[6][1][2])[2::]).upper()
    else:
        str7 = 'FFFF00'
    col_button7 = Button(bg='#'+str7, command=lambda : delete_col(col_button7,6))
    col_button7.place(x=800, y=420, height=30, width=75)

    if palette[7]:
        str8 = (hex(palette[7][1][0])[2::] + hex(palette[7][1][1])[2::] + hex(palette[7][1][2])[2::]).upper()
    else:
        str8 = 'FFFF00'
    col_button8 = Button(bg='#'+str8, command=lambda : delete_col(col_button8,7))
    col_button8.place(x=800, y=470, height=30, width=75)

def get_pdata():#提取主色调
    global palette
    palette = Haishoku.getPalette(file_path)
    print(palette)

def giveup_p(btn2,btn3):
    btn2.config(state=DISABLED)
    btn3.config(state=DISABLED)
    ft = tkFont.Font(size=30, weight=tkFont.BOLD)
    Label(text='已删除!',foreground="red",font=ft).place(x=240,y=20,height=512,width=512)
    os.remove(file_path)

def delete_col(btn,index):
    btn.config(state=DISABLED)
    palette[index] = 'deleted'
    print("删除第%d个色调"%(index+1))

def save_pinfo(btn2,btn3):
    global id
    #D:/py/workpace/mydata/１号大街(120.33374939535337,30.291286725849943)1563800672.1981633.jpeg
    regex1 = '/(\w*)'
    regex2 = '(\d*.\d*),\d*.\d*'
    regex3 = '\d*.\d*,(\d*.\d*)'
    pattern1 = re.compile(regex1)
    pattern2 = re.compile(regex2)
    pattern3 = re.compile(regex3)
    match1 = pattern1.findall(file_path)
    match2 = pattern2.findall(file_path)
    match3 = pattern3.findall(file_path)
    name = match1[4]
    longitude = match2[0]
    latitude = match3[0]

    btn2.config(state=DISABLED)
    btn3.config(state=DISABLED)
    palettelist = []
    for i in range(len(palette)):
        if palette[i] != 'deleted':
            palettelist.append(palette[i][1])
    if len(palettelist)<4:
        for j in range(4-len(palettelist)):
            palettelist.append((255,255,0))
    palettestr = (palettelist[0],palettelist[1],palettelist[2],palettelist[3])
    with open('C:\\Users\\27539\\Desktop\\导师\\done\\' + 'p_info.csv', 'a', newline='') as f:
        csv_writer = csv.writer(f)
        csv_writer.writerow([id,name,longitude,latitude,palettestr[0],palettestr[1],palettestr[2],palettestr[3]])
    id += 1
    print('保存成功！')
    ft = tkFont.Font(size=30, weight=tkFont.BOLD)
    Label(text='请上传图片!', foreground="red", font=ft).place(x=240, y=20, height=512, width=512)
    os.remove(file_path)

button1 =Button(text='上传图片',
                bg='#d3fbfb',
                command=lambda : Upload_Img(button2,button3))
button1.place(x=40,y=80,height=50,width=150)
#csv文件及逻辑初始化
with open('C:\\Users\\27539\\Desktop\\导师\\done\\' + 'p_info.csv', 'a', newline='') as f:
    csv_writer = csv.writer(f)
    csv_writer.writerow(['id','name','longitude','latitude','color1','color2','color3','color4'])
id = 1
button2 =Button(text='保存信息',
                bg='#d3fbfb',command=lambda : save_pinfo(button2,button3))
button2.place(x=40,y=150,height=50,width=150)
button3 =Button(text='舍弃图片',
                bg='#d3fbfb',
                command=lambda : giveup_p(button2,button3))
button3.place(x=40,y=220,height=50,width=150)
window.mainloop()