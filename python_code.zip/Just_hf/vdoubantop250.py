# -*- coding:utf-8 -*-
# _author_: Mr.Wang

import requests
from lxml import etree
import re
from selenium import webdriver
import csv

infolist = []
finalist = []


def get_movieinfo():
    start = 0
    global infolist
    name = '//div[@id="content"]//li//div[@class="info"]//a//span[1]/text()'
    number = '//div[@id="content"]//li//div[@class="info"]//div[@class="star"]/span[2]/text()'
    type = '//div[@id="content"]//li//div[@class="bd"]/p/text()[2]'

    for i in range(10):
        url = 'https://movie.douban.com/top250?start=' + str(start) + '&filter='
        response = requests.get(url)
        htm = etree.HTML(response.text)
        namelist = htm.xpath(name)
        numberlist = htm.xpath(number)
        typelist1 = htm.xpath(type)

        typeregex = '\D+\xa0/\xa0(.*)\n'
        pattern = re.compile(typeregex)
        typelist = []
        for j in range(len(typelist1)):
            match = pattern.findall(typelist1[j])
            if match:
                typelist.append(match[0])
        if len(namelist) == len(numberlist) == len(typelist):
            for k in range(len(typelist)):
                infolist.append(namelist[k] + ',' + numberlist[k] + ',' + typelist[k])
        start = start + 25
    print(len(infolist))


def run():
    global infolist
    global finalist
    # for i in range(126):#126\186\187
    #     info = infolist.pop()
    length_ = len(infolist)
    for i in range(length_):
        # if i==126 or i==186 or i==187:
        #     info = infolist.pop()
        #     print(info.split(',')[0])
        #     continue
        info = infolist.pop()
        keyword = ''
        try:
            klist = info.split(',')[0].encode('gb2312')
            for j in range(len(klist)):
                keyword = keyword + '%' + str(hex(klist[j]))[2:].upper()
            url2 = 'http://s.ygdy8.com/plus/so.php?typeid=1&keyword=' + keyword
            driver = webdriver.Chrome()
            driver.get(url2)
            driver.implicitly_wait(5)
            text2 = driver.page_source
            driver.close()
            htm2 = etree.HTML(text2)
            urlist2 = htm2.xpath('//div[@class="bd3r"]//ul//a/@href')
            if urlist2:
                url3 = 'https://www.ygdy8.com' + urlist2[0]
            else:
                url3 = 'none'
            finalist.append(info + ',' + url3)
        except(Exception):
            finalist.append(info + ',' + 'none')
            print(info)
        print(i)
    print(len(finalist))


if __name__ == '__main__':

    get_movieinfo()
    run()

    with open('C:\\Users\\86178\\Desktop\\top250.csv', 'a', newline='') as f:
        csv_writer = csv.writer(f)
        for i in range(len(finalist)):
            csv_writer.writerow([finalist[i].split(',')[0], finalist[i].split(',')[1], finalist[i].split(',')[2],
                                 finalist[i].split(',')[3]])