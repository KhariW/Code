# -*- coding:utf-8 -*-
# _author_: Mr.Wang
import requests
from selenium import webdriver
from lxml import etree
import re
import  csv
from threading import Thread
import json

id_list = []
ex_id_list = []
final_info_list = []
def make_id_list():
    global  id_list
    url = 'http://quote.eastmoney.com/stock_list.html'

    driver = webdriver.Chrome()
    driver.get(url)
    driver.implicitly_wait(5)
    text = driver.page_source
    driver.close()


    htm = etree.HTML(text)
    list2 = htm.xpath('//ul/a[@name="sh"]/../li/a[@target="_blank"]/@href')
    list3 = htm.xpath('//ul/a[@name="sz"]/../li/a[@target="_blank"]/@href')

    idregex = '/(\w+\d+)'
    idpattern = re.compile(idregex)
    for i in list2:
        idmatch = idpattern.findall(i)
        id_list.append(idmatch[0])
    for j in list3:
        idmatch = idpattern.findall(j)
        id_list.append(idmatch[0])
    print(len(id_list))
    # id_list = []
    # id_list.append('sh203020')
    # id_list.append('sh203007')
    # id_list.append('sh202007')
# 股票页数据
def get_eachinfo():
    global id_list
    #
    if id_list:
        id = id_list.pop()
    else:
        return
    #
    print(id)
    reuquireid = id[2:5:]
    if reuquireid != '600' and reuquireid != '601' and reuquireid != '602' and reuquireid != '603' and reuquireid != '688' and reuquireid != '000' and reuquireid != '001' and reuquireid != '002' and reuquireid != '300':
        return
    if id[1] == 'z':
        secid = '0.' + id[2::]
    elif id[1] == 'h':
        secid = '1.' + id[2::]

    try:
        url = 'http://push2.eastmoney.com/api/qt/stock/get?ut=fa5fd1943c7b386f172d6893dbfba10b&invt=2&fltt=2&fields=f43,f57,f58,f169,f170,f46,f44,f51,f168,f47,f164,f163,f116,f60,f45,f52,f50,f48,f167,f117,f71,f161,f49,f530,f135,f136,f137,f138,f139,f141,f142,f144,f145,f147,f148,f140,f143,f146,f149,f55,f62,f162,f92,f173,f104,f105,f84,f85,f183,f184,f185,f186,f187,f188,f189,f190,f191,f192,f107,f111,f86,f177,f78,f110,f262,f263,f264,f267,f268,f250,f251,f252,f253,f254,f255,f256,f257,f258,f266,f269,f270,f271,f273,f274,f275,f127,f199,f128,f193,f196,f194,f195,f197,f80,f280,f281,f282,f284,f285,f286,f287&secid=' + secid
        headers1 = {
            'Connection': 'keep-alive',
            'Host': 'push2.eastmoney.com',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'}
        headers1['Referer'] = 'http://quote.eastmoney.com/' + id + '.html'

        response1 = requests.get(url,headers=headers1)

        response1dict = json.loads(response1.text)

        final_info = response1dict["data"]["f58"]+'!'+response1dict["data"]["f57"]+'!'+str(response1dict["data"]["f43"])+'!'+str(response1dict["data"]["f47"])+'!'+str(response1dict["data"]["f168"])+'!'+str(response1dict["data"]["f162"])

#财务分析
        apiurl = 'http://f10.eastmoney.com/NewFinanceAnalysis/MainTargetAjax?type=2&code='+id.upper()
        headers2 = {
                'Connection': 'keep-alive',
                'Host': 'f10.eastmoney.com',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36',
        }
        headers2['Referer'] = 'http://f10.eastmoney.com/f10_v2/FinanceAnalysis.aspx?code='+id
        response2 = requests.get(apiurl,headers=headers2)

        dateregex = '"date":"(.*?)"'
        datepattern = re.compile(dateregex)
        datematch = datepattern.findall(response2.text)

        kfjlrregex = '"kfjlr":"(.*?)"'
        kfjlrpattern = re.compile(kfjlrregex)
        kfjlrmatch = kfjlrpattern.findall(response2.text)

        if not kfjlrmatch:
            for i in range(9):
                final_info = final_info+'!none'
        else:
            for i in kfjlrmatch:
                final_info = final_info+'!'+i
        final_info_list.append(final_info)
        # print(final_info)
        # print(kfjlrmatch)
        # print('\n')
        # print(final_info_list)

        return
    except Exception as e:
        ex_id_list.append(id)
        print(e)
        return


if __name__ == '__main__':
    make_id_list()
    # with open('C:\\Users\\WHR\\Desktop\\id_list.csv', 'a', newline='') as f:
    #     csv_writer = csv.writer(f)
    #     for i in range(len(id_list)):
    #         csv_writer.writerow([id_list[i]])

    while id_list:
        threadList = []

        for i in range(15):
            t = Thread(target=get_eachinfo, args=())
            t.start()
            threadList.append(t)

        for t in threadList:
            t.join()

    with open('C:\\Users\\WHR\\Desktop\\ex_id_list.csv', 'a', newline='') as f:
        csv_writer = csv.writer(f)
        for i in range(len(ex_id_list)):
            csv_writer.writerow([ex_id_list[i]])

    with open('C:\\Users\\WHR\\Desktop\\info.csv', 'a', newline='') as f:
        csv_writer = csv.writer(f)
        for i in range(len(final_info_list)):
            try:
                csv_writer.writerow([final_info_list[i].split('!')[0],final_info_list[i].split('!')[1],final_info_list[i].split('!')[2],final_info_list[i].split('!')[3],final_info_list[i].split('!')[4],final_info_list[i].split('!')[5],final_info_list[i].split('!')[6],final_info_list[i].split('!')[7],final_info_list[i].split('!')[8],final_info_list[i].split('!')[9],final_info_list[i].split('!')[10],final_info_list[i].split('!')[11],final_info_list[i].split('!')[12],final_info_list[i].split('!')[13],final_info_list[i].split('!')[14]])
            except Exception:
                print(final_info_list[i])

