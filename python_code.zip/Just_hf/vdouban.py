# -*- coding:utf-8 -*-
# _author_: Mr.Wang

import requests
from lxml import etree
from selenium import webdriver
import time
# from threading import Thread
import csv
infolist = []
finalist = []

def get_movieinfo(typename):
    global infolist
    dic = {'剧情':'11','喜剧':'24','动作':'5','爱情':'13','科幻':'17','动画':'25','悬疑':'10','惊悚':'19',
            '恐怖': '20','纪录片':'1','情色':'6'}
    type_ = dic.get(typename)
    url = 'https://movie.douban.com/typerank?type_name='+typename+'&type='+type_+'&interval_id=100:90&action='
    driver = webdriver.Chrome()
    driver.get(url)
    driver.implicitly_wait(5)
    for y in range(200):
        js = "window.scrollBy(0,100)"
        driver.execute_script(js)
        time.sleep(0.2)
    text = driver.page_source
    driver.close()

    htm = etree.HTML(text)
    namelist = htm.xpath('//div[@class="movie-info"]/div[@class="movie-name"]//a/text()')
    numberlist = htm.xpath('//div[@class="movie-rating"]/span[@class="rating_num"]/text()')
    for i in range(len(namelist)):
        if float(numberlist[i]) >= 8.6:
            try:
                infolist.append(namelist[i]+','+numberlist[i])
            except Exception:
                pass
    print(len(namelist))
    print(len(numberlist))
    print(len(infolist))
def run():
    global infolist
    global finalist
    length_ = len(infolist)
    for i in range(length_):
        try:
            info = infolist.pop()
        except Exception:
            pass
        keyword = ''
        klist = info.split(',')[0].encode('gb2312')
        for j in range(len(klist)):
            keyword = keyword+'%'+str(hex(klist[j]))[2:].upper()
        url2 = 'http://s.ygdy8.com/plus/so.php?typeid=1&keyword='+keyword
        driver = webdriver.Chrome()
        driver.get(url2)
        driver.implicitly_wait(5)
        text2 = driver.page_source
        driver.close()
        htm2 = etree.HTML(text2)
        urlist2 = htm2.xpath('//div[@class="bd3r"]//ul//a/@href')
        if urlist2:
            url3 = 'https://www.ygdy8.com' + urlist2[0]
        else:
            url3 = 'none'
        finalist.append(info+','+url3)
    print(len(finalist))


if __name__ == '__main__':

    type_name = input("请输入电影类别：")
    get_movieinfo(type_name)
    run()
    # threadList = []
    # for i in range(4):
    #     t = Thread(target=run, args=())
    #     t.start()
    #     threadList.append(t)
    #
    # for t in threadList:
    #     t.join()

    with open('D:\\py\\workpacedata\\' + type_name+'.csv', 'a', newline='') as f:
        csv_writer = csv.writer(f)
        for i in range(len(finalist)):
            csv_writer.writerow([finalist[i].split(',')[0],finalist[i].split(',')[1],finalist[i].split(',')[2]])