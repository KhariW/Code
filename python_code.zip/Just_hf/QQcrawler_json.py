import requests
import re
from selenium import webdriver
import csv
import json
import time

contentlist = []
GPSlist = []
uin = '1439923427'
def get_g_tk(cookie):
    hashes = 5381
    for letter in cookie['p_skey']:
        hashes += (hashes << 5) + ord(letter)  # ord()是用来返回字符的ascii码
    return hashes & 0x7fffffff


#这个函数是用来获取cookie,g_tk,g_qzontoken这三个数据
def Login_QQ():
    driver = webdriver.Chrome()
    start_url = "https://user.qzone.qq.com/"+uin
    driver.get(start_url)
    time.sleep(10)
    cookie = {}
    for elem in driver.get_cookies():
        cookie[elem['name']] = elem['value']
    html = driver.page_source
    g_qzonetoken = re.search(r'window\.g_qzonetoken = \(function\(\)\{ try\{return (.*?);\} catch\(e\)',html)
    g_tk = get_g_tk(cookie)
    # driver.quit()
    # print(g_qzonetoken.group(1))
    # print(cookie)
    return (cookie, g_tk, g_qzonetoken.group(1))


def get_soth():
    cookie,g_tk,qzonetoken = Login_QQ()
    pos = 0
    while pos<=80:
        url = 'https://user.qzone.qq.com/proxy/domain/taotao.qq.com/cgi-bin/emotion_cgi_msglist_v6?uin='+uin+'&inCharset=utf-8&outCharset=utf-8&hostUin='+uin+'&notice=0&sort=0&pos='+str(pos)+'&num=20&cgi_host=https%3A%2F%2Fuser.qzone.qq.com%2Fproxy%2Fdomain%2Ftaotao.qq.com%2Fcgi-bin%2Femotion_cgi_msglist_v6&code_version=1&format=jsonp&need_private_comment=1' \
            '&g_tk='+str(g_tk)+'&qzonetoken='+str(qzonetoken)+'&g_tk='+str(g_tk)

        response = requests.get(url,cookies=cookie)
        responsedict = json.loads(response.text[10:-2:])
        try:
            for each in responsedict['msglist']:
                if 'story_info' in each:
                    contentlist.append(each['content'])
                    GPSlist.append((each['story_info']['lbs']['pos_x'],each['story_info']['lbs']['pos_y']))
            print(pos)

        except(Exception):
            pass
        pos = pos + 20
    print(contentlist)
    print(GPSlist)

    with open('C:\\Users\\27539\\Desktop\\test.csv', 'a', newline='') as f:
        csv_writer = csv.writer(f)
        for i in range(len(contentlist)):
            csv_writer.writerow([contentlist[i], GPSlist[i][0], GPSlist[i][1]])






if __name__ == '__main__':

    get_soth()