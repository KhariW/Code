# -*- coding:utf-8 -*-
# _author_: Mr.Wang
import requests
from selenium import webdriver
from threading import Thread
from lxml import etree
import re
import  csv

id_list = []
ex_id_list = []
final_info_list = []
def make_id_list():
    global  id_list
    url = 'http://quote.eastmoney.com/stock_list.html'

    driver = webdriver.Chrome()
    driver.get(url)
    driver.implicitly_wait(5)
    text = driver.page_source
    driver.close()


    htm = etree.HTML(text)
    list2 = htm.xpath('//ul/a[@name="sh"]/../li/a[@target="_blank"]/@href')
    list3 = htm.xpath('//ul/a[@name="sz"]/../li/a[@target="_blank"]/@href')

    idregex = '/(\w+\d+)'
    idpattern = re.compile(idregex)
    for i in list2:
        idmatch = idpattern.findall(i)
        id_list.append(idmatch[0])
    for j in list3:
        idmatch = idpattern.findall(j)
        id_list.append(idmatch[0])
    id_list = []
    id_list.append('sh501019')
    id_list.append('sz300004')
# 股票页数据
def get_eachinfo(id):

    try:
        url = 'http://quote.eastmoney.com/'+id+'.html'

        driver = webdriver.Chrome()
        driver.get(url)
        driver.implicitly_wait(5)
        text = driver.page_source
        driver.close()

        htm = etree.HTML(text)
        if 'sz' in id:
            namelist = htm.xpath('//div[@class="qphox header-title mb7"]/h2/text()')
            idlist = htm.xpath('//div[@class="qphox header-title mb7"]/b/text()')
            rangelist = htm.xpath('//div[@id="arrowud"]/strong/text()')
            down_uplist = htm.xpath('//div[@id="arrowud"]/i/@class')
            cjllist = htm.xpath('//tbody//td[@id="gt5"]/text()')
            exchangehandlist = htm.xpath('//tbody//td[@id="gt4"]//text()')
            shiyinglist = htm.xpath('//span[@id="dtsyl"]/text()')
        elif 'sh' in id:
            namelist = htm.xpath('//div[@class="quote_title"]/span[1]/text()')
            idlist = htm.xpath('//div[@class="quote_title"]/span[2]/text()')
            rangelist = htm.xpath('//div[@id="arrowud"]/strong/text()')
            down_uplist = htm.xpath('//div[@id="arrowud"]/i/@class')
            cjllist = htm.xpath('//span[@class="cjl"]/text()')
            exchangehandlist = htm.xpath('//td[@class="txtl hsl"]/text()')
            shiyinglist = htm.xpath('//td[@class="txtl syl"]/text()')

        if 'up' in down_uplist[0]:
            down_up = 'up'
        elif 'down' in down_uplist[0]:
            down_up = 'down'

        final_info = namelist[0]+'!'+idlist[0]+'!'+rangelist[0]+'!'+down_up+'!'+cjllist[0]+'!'+exchangehandlist[0]+'!'+shiyinglist[0]


#财务分析
        apiurl = 'http://f10.eastmoney.com/NewFinanceAnalysis/MainTargetAjax?type=2&code='+id.upper()
        headers = {
                'Connection': 'keep-alive',
                'Host': 'f10.eastmoney.com',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36',
        }
        headers['Referer'] = 'http://f10.eastmoney.com/f10_v2/FinanceAnalysis.aspx?code='+id
        response = requests.get(apiurl,headers=headers)

        dateregex = '"date":"(.*?)"'
        datepattern = re.compile(dateregex)
        datematch = datepattern.findall(response.text)

        kfjlrregex = '"kfjlr":"(.*?)"'
        kfjlrpattern = re.compile(kfjlrregex)
        kfjlrmatch = kfjlrpattern.findall(response.text)


        for i in kfjlrmatch:
            final_info = final_info+'!'+i
        final_info_list.append(final_info)
        return
    except(Exception):
        ex_id_list.append(id)
        return


def work(id_list, name):
    print(name, "Start。。。")
    for each in id_list:
        get_eachinfo(each)

def split_job(length, sep):
    '''
    将 length分成 sep份
    '''
    result = []
    each = length//sep
    for i in range(sep):
        result.append((i*each, i*each+each))

    if length % sep:
        result.append((result[-1][1], length))

    return result

if __name__ == '__main__':
    make_id_list()
    job_list = split_job(len(id_list), 2)

    # print(id_list)
    t_list = []
    for index,each in enumerate(job_list):
        t_list.append(Thread(target=work, args=(id_list[each[0]:each[1]],"Thread_"+str(index),)))


    for each in t_list:
        each.start()

    for each in t_list:
        each.join()

    # with open('C:\\Users\\WHR\\Desktop\\ex_id_list.csv', 'a', newline='') as f:
    #     csv_writer = csv.writer(f)
    #     for i in range(len(ex_id_list)):
    #         csv_writer.writerow([ex_id_list[i]])
    #
    # with open('C:\\Users\\WHR\\Desktop\\info.csv', 'a', newline='') as f:
    #     csv_writer = csv.writer(f)
    #     for i in range(len(final_info_list)):
    #         csv_writer.writerow([final_info_list[i].split('!')[0],final_info_list[i].split('!')[1],final_info_list[i].split('!')[2],final_info_list[i].split('!')[3],final_info_list[i].split('!')[4],final_info_list[i].split('!')[5],final_info_list[i].split('!')[6],final_info_list[i].split('!')[7],final_info_list[i].split('!')[8],final_info_list[i].split('!')[9],final_info_list[i].split('!')[10],final_info_list[i].split('!')[11],final_info_list[i].split('!')[12],final_info_list[i].split('!')[13],final_info_list[i].split('!')[14],final_info_list[i].split('!')[15]])