# -*- coding:utf-8 -*-
# _author_: Mr.Wang

import requests
from lxml import etree
import time
from selenium import webdriver

final_info = []

url = 'https://liangpinpuzi.tmall.com/search.htm?spm=a1z10.3-b-s.w4011-14632554911.268.283861aeCMw4Gl&search=y&scene=taobao_shop&pageNo=1&tsearch=y#anchor'
driver = webdriver.Chrome()
driver.get(url)
driver.implicitly_wait(5)
for y in range(75):
   js = "window.scrollBy(0,100)"
   driver.execute_script(js)
   time.sleep(0.2)
res = driver.page_source
driver.close()

def get_goods(response_text):
    # xpath得到某一页所有商品链接
    res = etree.HTML(response_text)
    goodsurl_ = res.xpath('//div[@class="item5line1"]//dd[@class="detail"]/a/@href')
    for i in range(len(goodsurl_)):
        goodsurl_[i] = 'https:' + goodsurl_[i]

    # 得到商品参数，销量，买家信息，活动优惠（可选）  ，评价，名称，价格，
    while goodsurl_:
        goodurl = goodsurl_.pop()
        response = requests.get(goodurl)
        res2 = etree.HTML(response.text)
        #销量
        sellcount_ = res2.xpath('//li[@data-label="月销量"]//span[@class="tm-count"]/text()')
        sellcount_str = sellcount_[0]
        #商品参数
        goodpara_ = res2.xpath('//ul[@id="J_AttrUL"]/li/text()')
        goodpara_str = ''
        for i in range(len(goodpara_)):
            goodpara_str = goodpara_str + goodpara_[i]
        goodpara_str = goodpara_str.replace(' ','').replace('\n',',')
        #商品名称
        goodname_ = res2.xpath('//h1[@data-spm]/text()')
        goodname_str = goodname_[0].replace(' ','').replace('\n','')
        # 评价
        posi_ = res2.xpath('//span[@class="tag-posi"]/a/text()')
        neg_ = res2.xpath('//span[@class="tag-neg"]/a/text()')
        total_ = res2.xpath('//div[@class="rate-score"]/strong/text()')

        #价格
        price_ = res2.xpath('//dl[@class="tm-price-panel tm-price-cur"]//span[@class="tm-price"]/text()')
        price_str = price_[0]

        final_info = []


get_goods(res.text)