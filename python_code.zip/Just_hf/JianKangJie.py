import requests
from lxml import  etree
from jieba import analyse
#获得标题及文章地址
url = 'https://www.cn-healthcare.com/'
response1 = requests.get(url)
response1.encoding = "utf-8"
# print(response.text)
htm1 = etree.HTML(response1.text)
titlelist = htm1.xpath('//div[@class="main-textbox"]//li/@listtitlecont')
urllist = htm1.xpath('//div[@class="main-textbox"]//li/@listtitlecont2')
# title = titlelist[0]
# arturl = urllist[0]

#获得文章内容及文章作者
author_list = []
keywords_list = []

for i in range(len(urllist)):
    response2 = requests.get(urllist[i])
    response2.encoding = "utf-8"
    htm2 = etree.HTML(response2.text)
    #作者三种情况:要么是公众号，要么是作者，要么没有
    author = ''
    authorlist = htm2.xpath('//span[@class="wz-laiyuan"]/text()')
    if authorlist:
        author = authorlist[0]
    authorlist = htm2.xpath('//span[@class="nw-pcztuboxa"]/a/text()')
    if authorlist:
        author = authorlist[0]
    author_list.append(author)

    #content可能没有，当是一个视频的时候
    keyword = ''
    content = ''
    contentlist= htm2.xpath('//div[@class="wz-textbox"]/p//text()')
    if not contentlist:
        content = '这不是一篇文章'
    else:
        for j in range(len(contentlist)):
            content = content+contentlist[j]+'\n'
    if contentlist:
        keywords = analyse.extract_tags(content, withWeight=True)
        # print(keywords)
        for k in range(9):
            keyword = keyword+keywords[k][0]+','
        keyword = keyword+keywords[9][0]
    keywords_list.append(keyword)


# 到这一步，titlelist、urllist、author_list、keywords_list全部构造完成
for i in range(len(titlelist)):
    print('title：'+titlelist[i])
    print('article_url：'+urllist[i])
    print('author：'+author_list[i])
    print('keyword:'+keywords_list[i])
    print(' ')