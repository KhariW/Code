import requests
import re
from lxml import etree

problem_kw = ['NP完全问题','NPC问题']

def get_totpnum(kw):
	tpnl = ['0']
	tpn = ''
	while tpnl:
		url = 'https://www.google.com/search?q='+kw+'&start='+tpnl[0]
		headers = {'authority': 'www.google.com',
		'accept-language': 'zh-CN,zh;q=0.9',
		'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36'
		}
		response = requests.get(url,headers = headers)
		res = etree.HTML(response.text)
		tpnl = res.xpath("//div[@id='navcnt']//td[last()-1]/a/@aria-label")
		if tpnl:
			tpnl[0] = str((int(tpnl[0].replace('Page ',''))-1)*10)
		else:
			tpn = res.xpath("//div[@id='navcnt']//td[last()-1]/text()")[0]
			return int(tpn)

def get_urlsitetit(kw,tpn):
	finall = []
	for i in range(tpn):
		url = 'https://www.google.com/search?q='+kw+'&start='+str(i*10)
		headers = {'authority': 'www.google.com',
		'accept-language': 'zh-CN,zh;q=0.9',
		'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36'
		}

		response = requests.get(url,headers = headers)
		res = etree.HTML(response.text)
		urll = res.xpath("//div[@class='r']/a[1]/@href")
		titlel = res.xpath("//div[@class='r']/a[1]/h3/text()")
		regex = '//(.*?)/'
		pattern = re.compile(regex)
		for i in range(len(urll)):
			finall.append((urll[i],titlel[i],pattern.findall(urll[i])[0]))
	return finall

for each in problem_kw:
	tpn = get_totpnum(each)
	finall = get_urlsitetit(each,tpn)
	path = 'C:\\Users\\WHR\\Desktop\\'+each+'.txt'
	with open(path,'w') as f:
		for i in range(len(finall)):
			try:
				f.write(finall[i][0]+'\t\t'+finall[i][1]+'\t\t'+finall[i][2]+'\t\t'+str(i)+'\n')
			except Exception:
				pass
