class HfmTNode:			#赫夫曼节点
	def __init__(self,character=None,weight=0.0):
		self.lchild = None
		self.rchild = None
		self.cod = ''
		self.character =  character
		self.weight = weight
class HLNode:			#赫夫曼节点链表节点
	def __init__(self,htnode):
		self.htnode = htnode
		self.nex = None
		self.prior = None