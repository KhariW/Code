from DefNode import HfmTNode,HLNode
from Hfmop import *

# 建立字符权重链表			参数[('a',2.5),('b',1)...]   cwl:character weight link list
def CreateCwl(cl):
	cl.sort(key=lambda each:each[1],reverse=True)
	headhn = HfmTNode()
	headhl = HLNode(headhn)
	pp = pn = headhl
	for each in cl:
		hl = HLNode(HfmTNode(each[0],each[1]))
		pn.nex = hl
		pn = pn.nex
		pn.prior = pp
		pp = pp.nex
	fp = headhl.nex
	lp = pp
	fp.prior = None
	headhl.nex = None

	# p = fp
	# while p:
	# 	print('('+p.htnode.character+','+str(p.htnode.weight)+')',end="->")
	# 	p = p.nex
	# print('')
	# p = lp
	# while p:
	# 	print('('+p.htnode.character+','+str(p.htnode.weight)+')',end="->")
	# 	p = p.prior
	return fp,lp

def InputToCl():
	chsi = input("\n\n\t\t\t请输入字符集大小N：")
	cl = []
	for i in range(int(chsi)):
		caw = input("\t\t\t请输入字符及权值，以逗号分隔：")
		cl.append((caw.split(',')[0],float(caw.split(',')[1])))
	# cl = [('a',2.5),('b',1),('v',2.4),('d',7.3)]  #cl:character list
	cl = [('A',64),('B',13),('C',22),('D',32),('E',103),('F',21),('G',15),('H',47),('I',57),('J',1),('K',5),('L',32),('M',20),('N',57),('O',63),('P',15),('Q',1),('R',48),('S',51),('T',80),('U',23),('V',8),('W',18),('X',1),('Y',16),('Z',1),(' ',186)]
	return cl
if __name__ == '__main__':
                                                                          
	print('''                      _                        _           
                     | |                      | |          
                     | | _  _   _        _ _ _| | _   ____ 
                     | || \| | | |      | | | | || \ / ___)
                     | |_) ) |_| |      | | | | | | | |    
                     |____/ \__  |       \____|_| |_|_|    
                           (____/                          ''')
	cl = InputToCl()
	flag = '(未初始化)'
	cmd = input("\n\t\t\t请输入命令"+flag+"：\n\t\t\tI:初始化赫夫曼树\n\t\t\tE:编码\n\t\t\tD:译码\n\t\t\tRI:重置赫夫曼树\n\t\t\tQ:退出\n\t\t\t")
	while cmd != 'Q':
		if cmd == 'I':
			fp,lp = CreateCwl(cl)
			hft = CreateHfmTree(fp,lp)
			flag = '(已初始化)'
		# Inordertraverse(hft)
		# print(hfmtable)
	
		# Inordertraverse(Allothft())
		if cmd == 'E':
			enco = 1
			hfmtable = []
			try:
				CreateHfmTable(Allothft(),hfmtable)
			except Exception as e:
				print("\n\t\t\t未初始化！！！！！！")
				enco = 0
			if enco == 1:
				try:
					Encoding(hfmtable)
				except Exception:
					print("\n\t\t\t未找到待编码文件！！！！！！")
		if cmd == 'D':
			try:
				Decoding(Allothft())
			except Exception:
				print("\n\t\t\t未找到待解码文件！！！！！！")
		if cmd == 'RI':
			cl = InputToCl()
			fp,lp = CreateCwl(cl)
			hft = CreateHfmTree(fp,lp)
		cmd = input("\n\t\t\t请输入命令"+flag+"：\n\t\t\tI:初始化赫夫曼树\n\t\t\tE:编码\n\t\t\tD:译码\n\t\t\tRI:重置赫夫曼树\n\t\t\tQ:退出\n\t\t\t")
	