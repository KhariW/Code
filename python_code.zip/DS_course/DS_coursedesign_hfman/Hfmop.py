from DefNode import HfmTNode,HLNode
hfmtreefile = "HfmTree.txt"
tobetranfile = "ToBeTran.txt"
codefile = "CodeFile.txt"
textfile = "TextFile.txt"
# 建立赫夫曼树  
def CreateHfmTree(fp,lp):#建立树的过程中直接构建编码,根据有序链表头尾指针建立赫夫曼树
	while lp.prior.prior:
		hl1 = lp
		hl2 = lp.prior
		lp = lp.prior.prior
		lp.nex.prior = None
		lp.nex = None

		hl3 = HLNode(HfmTNode())
		hl3.htnode.character = None
		hl3.htnode.weight = hl1.htnode.weight+hl2.htnode.weight
		hl3.htnode.lchild = hl1
		hl3.htnode.rchild = hl2
		Inordertraverse0(hl1)                
		Inordertraverse1(hl2)

		p = lp
		if p.htnode.weight<hl3.htnode.weight:
			while p!=None and p.htnode.weight<hl3.htnode.weight:
				p = p.prior
			if p==None:
				hl3.nex = fp
				fp.prior = hl3
				fp = hl3
			else:
				hl3.nex = p.nex
				hl3.prior = p
				p.nex.prior = hl3
				p.nex = hl3
		else:
			p.nex = hl3
			hl3.prior = p
			lp = hl3
	hl1 = lp
	hl2 = lp.prior
	hl3 = HLNode(HfmTNode())
	hl3.htnode.character = None
	hl3.htnode.weight = hl1.htnode.weight+hl2.htnode.weight
	hl3.htnode.lchild = hl1
	hl3.htnode.rchild = hl2
	Inordertraverse0(hl1)
	Inordertraverse1(hl2)
	hft = hl3

	hfttoli = []
	suplist = []
	suplist.append(hft)
	while(suplist):
		hftn = suplist.pop(0)
		if isinstance(hftn,HLNode):
			hfttoli.append(str((hftn.htnode.character,hftn.htnode.weight,hftn.htnode.cod)))
		else:
			hfttoli.append('(0)')
			continue
		if hftn.htnode.lchild:
			suplist.append(hftn.htnode.lchild)
		else:
			suplist.append(0)
		if hftn.htnode.rchild:
			suplist.append(hftn.htnode.rchild)
		else:
			suplist.append(0)
	with open("HfmTree.txt","w") as f:
		for each in hfttoli:
			f.write(each)
	return hft 
#读取赫夫曼树
def Allothft():#读取特定文件，构造出赫夫曼树
	with open(hfmtreefile,"r") as f:
		hftstr = f.read()
		hftstr = hftstr.replace("(","")
		hftstrli = hftstr.split(")")
		hftstrli.pop()
	suplist = hftstrli[0].split(',')


	c = suplist[0]
	w = suplist[1]
	co = suplist[2]


	hhftn = HLNode(HfmTNode())
	if c!='None':
		hhftn.htnode.character = c[1:-1:]
	else:
		hhftn.htnode.character = None
	hhftn.htnode.weight = float(w)
	hhftn.htnode.cod = co[2:-1:]
	
	suplist2 = []
	suplist2.append(hhftn)
	i = 0
	while suplist2:
		suphftn = suplist2.pop(0)
		if hftstrli[i*2+1]!='0':
			suplist = hftstrli[i*2+1].split(',')
			c = suplist[0]
			w = suplist[1]
			co = suplist[2]
			newhftn = HLNode(HfmTNode())
			if c!='None':
				newhftn.htnode.character = c[1:-1:]
			else:
				newhftn.htnode.character = None
			newhftn.htnode.weight = float(w)
			newhftn.htnode.cod = co[2:-1:]
			suphftn.htnode.lchild = newhftn
			suplist2.append(suphftn.htnode.lchild)
		if hftstrli[i*2+2]!='0':
			suplist = hftstrli[i*2+2].split(',')
			c = suplist[0]
			w = suplist[1]
			co = suplist[2]
			newhftn = HLNode(HfmTNode())
			if c!='None':
				newhftn.htnode.character = c[1:-1:]
			else:
				newhftn.htnode.character = None
			newhftn.htnode.weight = float(w)
			newhftn.htnode.cod = co[2:-1:]
			suphftn.htnode.rchild = newhftn
			suplist2.append(suphftn.htnode.rchild)
		
		i = i+1
	hft = hhftn
	return hft

# 建立赫夫曼表
def CreateHfmTable(hft,hfmtable):#根据赫夫曼树构造赫夫曼表
	if hft:
		CreateHfmTable(hft.htnode.lchild,hfmtable)
		if hft.htnode.character!=None:
			hfmtable.append((hft.htnode.character,hft.htnode.cod))
		CreateHfmTable(hft.htnode.rchild,hfmtable)
# encode
def Encoding(hfmtable):#根据赫夫曼表对特定文件进行编码，输出到特定文件
	with open(tobetranfile,'r') as f:
		str_ = f.read()
	new_str = ''
	for i in range(len(str_)):
		for each in hfmtable:
			if str_[i]==each[0]:
				new_str = new_str+each[1]
	with open(codefile,'w') as f:
		f.write(new_str)
	# return new_str
# decode
def Decoding(hft):#根据赫夫曼树对特定文件进行解码，输出到特定文件
	with open(codefile,'r') as f:
		str_ = f.read()
	new_str = ''
	p = hft
	while str_:
		s = str_[0]
		str_ = str_[1::]
		if s=='0' and p.htnode.lchild:
			p = p.htnode.lchild
		if s=='0' and not p.htnode.lchild:
			new_str = new_str + p.htnode.character
			p = hft
		if s=='1' and p.htnode.rchild:
			p = p.htnode.rchild
		if s=='1' and not p.htnode.rchild:
			new_str = new_str + p.htnode.character
			p = hft
	with open(textfile,'w') as f:
		f.write(new_str)

#中序遍历函数以及用于建立编码的遍历函数
def Inordertraverse0(hft):
	if hft:
		Inordertraverse0(hft.htnode.lchild)
		hft.htnode.cod = '0'+hft.htnode.cod
		Inordertraverse0(hft.htnode.rchild)
def Inordertraverse1(hft):
	if hft:
		Inordertraverse1(hft.htnode.lchild)
		hft.htnode.cod = '1'+hft.htnode.cod
		Inordertraverse1(hft.htnode.rchild)
def Inordertraverse(hft):
	if hft:
		Inordertraverse(hft.htnode.lchild)
		print(hft.htnode.character,"权重:"+str(hft.htnode.weight)+"编码:"+hft.htnode.cod)
		Inordertraverse(hft.htnode.rchild)
