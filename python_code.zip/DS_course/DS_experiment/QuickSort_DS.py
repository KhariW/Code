class StuRecord:
	def __init__(self,number,name,grade):
		self.number = number           # int 
		self.name = name
		self.grade = grade            # float
	def __le__(self,rhs):        #self <= rhs       小于等于
		# print("__le__被调用")
		return(self.grade<=rhs.grade)
	def __ge__(self,rhs):        #self >= rhs       大于等于
		# print("__ge__被调用")
		return(self.grade>=rhs.grade)


def Partition(unolist,low,high,pivs):
	if pivs == 'F':
		reco_sup = unolist[low]
		pivotkey = unolist[low]
		print("枢轴："+"("+str(pivotkey.number)+'_'+pivotkey.name+'_'+str(pivotkey.grade)+")")
		while low<high:
			while low<high and unolist[high]<=pivotkey:
				high = high - 1
			unolist[low] = unolist[high]
			while low<high and unolist[low]>=pivotkey:
				low = low + 1
			unolist[high] = unolist[low]
		unolist[low] = reco_sup
		SortRecPrint(unolist,pivotkey)
		return low
	if pivs == 'L':
		reco_sup = unolist[high]
		pivotkey = unolist[high]
		print("枢轴："+"("+str(pivotkey.number)+'_'+pivotkey.name+'_'+str(pivotkey.grade)+")")
		while low<high:
			while low<high and unolist[low]>=pivotkey:
				low = low + 1
			unolist[high] = unolist[low]
			while low<high and unolist[high]<=pivotkey:
				high = high - 1
			unolist[low] = unolist[high]
		unolist[low] = reco_sup
		SortRecPrint(unolist,pivotkey)
		return low

def Qsort(unolist,low,high,pivs):
	if low<high:
		pivotloc = Partition(unolist,low,high,pivs)
		Qsort(unolist,low,pivotloc-1,pivs)
		Qsort(unolist,pivotloc+1,high,pivs)
def QuickSort(unolist,pivs='F'):   #######  'F' 'L' 'M'
	Qsort(unolist,0,len(unolist)-1,pivs)

def SLCreat():
	StuLi = []
	print("输入学生名单：\n")
	n = input("请输入学生人数：")
	for i in range(int(n)):
		number = input("请输入学号：")
		name = input("请输入姓名：")
		grade = input("请输入成绩：")
		print("输入成功！\n")
		StuLi.append(StuRecord(int(number),name,float(grade)))
	return StuLi
def SLPrint(stulist):
	print("学生成绩名单：")
	print("名次\t"+"学号\t"+"姓名\t"+"成绩")
	for i in range(len(stulist)):
		print(str(i+1)+'\t'+str(stulist[i].number)+'\t'+stulist[i].name+'\t'+str(stulist[i].grade))
	print('')
def SortRecPrint(unolist,pivotkey):
	for i in range(len(unolist)):
		if unolist[i] != pivotkey:
			print(str(stulist[i].number)+'_'+stulist[i].name+'_'+str(stulist[i].grade),end='')
		if unolist[i] == pivotkey:
			print("("+str(stulist[i].number)+'_'+stulist[i].name+'_'+str(stulist[i].grade)+")",end='')
		if i != (len(unolist)-1):
			print(' ',end='')
		if i == (len(unolist)-1):
			print('')
if __name__ == '__main__':
	stulist = SLCreat()
	print("未排序：")
	SLPrint(stulist)
	
	print("以第一个记录为枢轴：")
	QuickSort(stulist,'F')
	print("已排序(第一个记录为枢轴)：")
	SLPrint(stulist)

	print("以最后一个记录为枢轴：")
	QuickSort(stulist,'L')
	print("已排序(最后一个记录为枢轴)：")
	SLPrint(stulist)