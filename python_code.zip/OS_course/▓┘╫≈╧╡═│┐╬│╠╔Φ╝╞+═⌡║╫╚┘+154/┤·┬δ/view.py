def printLogin():
    username = input("login: ")
    password = input("Password: ")

    return username, password

if __name__ == "__main__":
    printLogin()