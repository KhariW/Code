from view import *
from func import  cd, checkPass,getpath, information, adduser, chroot, cp, mv
from utils import Folder, File, User
from config import userGroup, root
import os
import time
import platform

plat = platform.architecture()[1]

# 常量定义
if plat == "ELF":
    clearSin = 'clear'    # 清屏命令
elif plat == "WindowsPE":
    clearSin = "cls"
else:
    raise Exception("Uknown Plat")
user = None  # 当前用户
here = None  # 当前所在文件夹

os.system(clearSin)


while True:
    username, password = printLogin()
    user = checkPass(username, password)
    if user:
        break

here = user.home



def main():
    global here
    global user
    global clearSin
    while True:
        cmd = input("\033[33m{username}\033[30m@\033[31mOS \033[30m~\033[36m{time}\033[30m -> \033[34m{pwd} \033[0m> ".format(
            username=user.username, time=str(time.ctime()), pwd=getpath(here)))
        if len(cmd) == 0:
            continue
        if cmd == 'help':
            information()
        elif cmd == 'exit':
            print("bye~")
            break
        elif cmd == 'ls':
            here.showitems()
        elif cmd == 'clear':
            os.system(clearSin)
        else:
            cmd_list = cmd.split(" ")
            try:
                cmd = cmd_list[0]
                arg = cmd_list[1]
            except:
                print("Incorrect input format!")
                continue

            if cmd == 'cd':
                here = cd(arg, here, user.home)
            elif cmd == 'adduser':
                password = input("Please input password:")
                checkPas = input("Please repeat your password:")
                if password == checkPas:
                    adduser(arg, password)
                else:
                    print("Incorrect password!")
            elif cmd == 'chroot':
                password = input("Please input password:")
                temp = chroot(arg, password)
                if temp:
                    user = temp  # 更改当前用户
                    here = user.home
                    os.system(clearSin)
                    print("Welcome")
            elif cmd == 'cp':
                cp(arg, cmd_list[2], here, user.home)
            elif cmd == 'mv':
                mv(arg, cmd_list[2], here, user.home)
                
            elif cmd == 'touch':
                here.createfile(arg)
                
            elif cmd == 'rm':
                here.deletef(arg)
                
            elif cmd == 'cat':
                for each in here.files:
                    if each.name == arg:
                        each.showcontent()
                
            elif cmd == 'edit':
                con = input("请输入修改的内容:\n")
                for each in here.files:
                        if each.name == arg:
                            each.chcont(con)
                
            elif cmd == 'mkdir':
                here.createfolder(arg)
                


if __name__ == "__main__":
    main()