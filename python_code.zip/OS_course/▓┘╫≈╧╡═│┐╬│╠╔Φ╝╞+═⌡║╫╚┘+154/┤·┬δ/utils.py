class User():
    def __init__(self,name,pwd,home):
        self.username = name
        self.password = pwd
        self.home = home

class File():
    def __init__(self,name):
        self.name = name
        self.status = 1
        self.content = None
    def showcontent(self):#展示文件内容
        if self.status == 0:
            print("文件已被锁定")
            return
        self.status = 0
        if self.content == None:
            print("该文件为空")
        else:
            print(self.content)
        self.status = 1
    def chcont(self,newcontent):
        if self.status == 0:
            print("文件已被锁定")
            return
        self.status = 0
        self.content = newcontent
        self.status = 1

class Folder():
    def __init__(self,name,father):
        self.name = name
        self.files = []
        self.folders = []
        self.fatherfolder = father#father应为Folder()对象

    def deletef(self,fname):
        flag = False
        for each in self.folders:
            if each.name == fname:
                flag = True
                self.folders.remove(each)
                break
        for each in self.files:
            if each.name == fname:
                flag = True
                self.files.remove(each)
                break
        if flag == False:
            print("文件不存在")

    def createfile(self,filename):
        if not len(filename):
            print("文件名为空")
        flag = True
        for each in self.files:
            if each.name == filename:
                print("文件已存在")
                flag = False
                break
        if flag == True:
            file = File(filename)
            self.files.append(file)

    def createfolder(self,foldername):
        if ('..' in foldername) or('.' in foldername) or('-' in foldername) or ('~' in foldername):
            print("Error: the name \033[31m{}\033[0m is not allowed".format(foldername))
        elif not len(foldername):
            print("文件夹名为空")
        else:
            folder = Folder(foldername,self)
            self.folders.append(folder)
    
    def backpath(self):
        return self.fatherfolder

    def showitems(self):
        i = 0
        for each in self.files:
            print(each.name+':-', end="  ")
            i += 1
            if i % 5 == 0:
                print()

        for each in self.folders:
            print(each.name+':d', end="  ")
            i += 1
            if i % 5 == 0:
                print()

        if i % 5:
            print()


    
    

if __name__ == '__main__':
    folder1 = Folder('whr',None)
    folder1.createfile('firstfile')
    folder1.createfolder('firstfolder')
    for each in folder1.folders:
        print(each.fatherfolder.name)
    print(folder1.folders[0].backpath().name)
    print(folder1.backpath())
    folder1.showitems()
