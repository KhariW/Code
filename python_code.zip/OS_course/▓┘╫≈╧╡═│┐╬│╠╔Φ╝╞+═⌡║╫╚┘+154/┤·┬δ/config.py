#项目配置文件


from utils import Folder, User

# 根目录
root = Folder('/', None)
root.createfolder('root')
for i in range(len(root.folders)):
	if root.folders[i] == 'root':
		break
rootUser = User('root', '123', root.folders[i])

userGroup = {
    rootUser.username: rootUser
}

if __name__ == '__main__':
	root.showitems()
	print(root.folders[0].name)
	print(root.folders[0].backpath().name)
	print(userGroup)
