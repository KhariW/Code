from utils import Folder, File, User
from config import userGroup, root

def getpath(folder):

        path = folder.name
        upfolder = folder.fatherfolder
        while upfolder.name != '/':    # 如果不是根目录继续往上
            # 先拼接
            path = upfolder.name + '/' + path
            upfolder = upfolder.fatherfolder
        path = '/' + path
        return path

def adduser(username, password):#新建用户

	for each in userGroup.keys():
		if each == username:
			print("该用户名已经存在")
			return

	root.createfolder(username)
	for i in range(len(root.folders)):
		if root.folders[i] == username:
			break
	newUser = User(username, password, root.folders[i])# 创建新用户
	userGroup[username] = newUser   # 加入组
	print("创建成功")


def chroot(username, password):#切换用户

	for each, value in userGroup.items():
		if each == username:
			if value.password == password:
                # print("success!")
				return value
			else:
				print("Incorrect password")
			break
		else:
			print("该用户不存在")
	return False
def checkPass(username, password):#检查登录

	try:
		if userGroup.get(username, None).password == password:
			return userGroup.get(username, None)
		else:
			return False
	except:
		return False

def existpath(path,folder,user):#/usr/local  usr/local local
	pathlist = path.split('/')
	if pathlist[0] == '':
		if pathlist[1] == user.name and len(pathlist)==2:
			return user

	if pathlist[0] == '':
		if pathlist[1] != user.name:
			print("路径不存在")
			return folder


		folders_ = user.folders
		folder_ = None
		for i in range(2,len(pathlist)):
			folder_ = None
			for each in folders_:
				if pathlist[i] == each.name:
					folders_ = each.folders
					folder_ = each
					break
			if folder_ == None:
				print("路径不存在")
				return folder
		return folder_
	else:
		if(len(pathlist)==1):
			for each in folder.folders:
				if pathlist[0] == each.name:
					return each
			return folder
		else:
			folders_ = folder.folders
			folder_ = None
			for i in range(0,len(folderList)):
				folder_ = None
				for each in folders_:
					if pathlist[i] == each.name:
						folders_ = each.folders
						folder_ = each
						break
				if folder_ == None:
					print("路径不存在")
					return folder
			return folder_




def cd(path,folder,user):#切换路径
	
	return existpath(path,folder,user)


def cp(path1, path2, folder,user):#复制文件
	
	if len(path1.split('/'))!=1:
		lis = path1.split('/')
		filename = lis.pop()
		path1 = ''
		for i in range(len(lis)):
			path1 = path1 + lis[i] +'/'
		path1 = path1[:-1:]
		folder1 = existpath(path1,folder,user)
		folder2 = existpath(path2,folder,user)

		for each in folder1.files:
			if filename == each.name:
				folder2.createfile(filename)
				for each2 in folder2.files:
					if filename == each2.name:
						each2.chcont(each.content)

	if len(path1.split('/'))==1:
		for each in folder.files:
			if path1 == each.name:
				folder2 = existpath(path2,folder,user)
				folder2.createfile(path1)
				for each2 in folder2.files:
					if path1 == each2.name:
						each2.chcont(each.content)
						return
	

def mv(path1, path2, folder,user):
	
	if len(path1.split('/'))!=1:
		lis = path1.split('/')
		filename = lis.pop()
		path1 = ''
		for i in range(len(lis)):
			path1 = path1 + lis[i] +'/'
		path1 = path1[:-1:]

		folder1 = existpath(path1,folder,user)
		folder2 = existpath(path2,folder,user)

		for each in folder1.files:
			if filename == each.name:
				folder2.createfile(filename)
				for each2 in folder2.files:
					if filename == each2.name:
						each2.chcont(each.content)
						folder1.files.remove(each)

	if len(path1.split('/'))==1:
		for each in folder.files:
			if path1 == each.name:
				folder2 = existpath(path2,folder,user)
				folder2.createfile(path1)
				for each2 in folder2.files:
					if path1 == each2.name:
						each2.chcont(each.content)
						folder.files.remove(each)
						return 


def information():
    '''
    使用说明
    '''
    print("""
使用说明：命令  参数

普通文件操作
创建文件：touch <filename>
删除文件：rm <filename>
查看文件：cat <filename>
编辑文件：edit <filename>
复制文件: cp <path> <path>
移动文件: mv <path> <path>

文件夹操作
新建文件夹：mkdir <foldername>
删除文件夹: rm <foldername>
切换文件夹: cd <path>

用户操作
新建用户: adduser <username>
切换用户: chroot <username>

其他
查看帮助: help
列出文件: ls
清空屏幕: clear
退出: exit
    """)

if __name__ == '__main__':
	folder1 = Folder('whr',None)
	folder1.createfolder('firstfolder')
	folder1.folders[0].createfolder('secondfolder')
	folder1.folders[0].folders[0].createfolder('thirdfolder')
	folder1.folders[0].folders[0].createfile('fuck')

	mv('/whr/firstfolder/secondfolder/fuck','/whr/firstfolder',folder1.folders[0],folder1)
	folder1.folders[0].showitems()
	folder1.folders[0].folders[0].showitems()